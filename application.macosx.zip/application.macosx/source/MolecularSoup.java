import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class MolecularSoup extends PApplet {

                    //*******************MOLECULAR SOUP*******************//
                    //*****************by DEEPAK GOPINATH******************//
                    
                    //************* Project 1 - Graphical Tool ***************//
                    //********************  LMC 6310 ***********************//


ArrayList organismList = new ArrayList(); // List containing all organisms.
float growthThreshold = 0.94f; //The actual growth threshold for random node generation
int growthValueDisplay = 10; //The display value for the user. 

int startFlag = 0; //Flag to keep track of front page, instruction page etc...
float colorPerlin = 0;

public void setup()
{
  size(640, 480, P3D);
  background(0);
  fill(255);
  noStroke();
}



public void draw()
{
  background(0);
 
  
  if(startFlag == 0){
    
    //FRONT PAGE
 
    fill(255,25, 0);
    textAlign(CENTER);
    textSize(38);
    text("MoLeCulAr sOuP", width/2 , height/2 - 100);
    textSize(22);
    text("CrEAted bY", width/2, height/2 - 40);
    textSize(28);
    text("DeEpaK goPiNatH", width/2, height/2 + 15 );
    textSize(20);
    fill(255,255,0);
    text("Hit Space to Continue", width/2, height/2 + 170);
    
  }else if(startFlag == 1){
    
    //INSTRUCTION PAGE
    
    fill(255,25, 0);
    textAlign(CENTER);
    textSize(30);
    text("How to Use!", width/2, height/2 - 150);
    textSize(18);
    
    text("Click anywhere to instantiate a molecular cluster", width/2, height/2 - 40);
    text("Click 'H' or 'L' at the top right corner to change the growth rate", width/2, height/2 + 20);
    text("Click and drag the mouse and wait to see the whole system ", width/2, height/2 + 80);
    text("sway towards the direction of mouse movement", width/2, height/2 + 100);
    fill(255,255,0);
    textSize(20);
    text("Hit Space to Continue", width/2, height/2 + 170);
  }
  
  else if(startFlag > 1) {
  
  //Render the spheres
  background(0);
  stroke(3);   // Display the growth rate and also draw the up and down buttons
  fill(0,255, 0);
  textAlign(CENTER);
  textSize(18);
  text("Growth Rate", 580, 30);
  textSize(18);
  text("H", 580,50);
  text(growthValueDisplay, 580, 85);
  text("L", 580, 120);
  
  //Set up some lighting which glimmers
  
  colorPerlin = colorPerlin + 0.05f;
  directionalLight(map(noise(colorPerlin), 0, 1, 10, 200), map(noise(1002+ colorPerlin), 0, 1, 10, 255), map(noise(2000+ colorPerlin), 0, 1, 160, 200), 0, 0, -1); // Set up some directional lighting. White Light shining from -z direction
  lightSpecular(204, 204, 204);
  directionalLight(102, 102, 102, 0, 1, -1);  
  lightSpecular(102, 102, 102);
  
  noStroke();
  fill(255);
  
  for(int i=organismList.size() - 1; i >= 0; i--) // Render each organism. Do the loop in the reverse order so that the list
                                                  //   can be dynamically modified within the loop and still we would not miss an organism
    {
      Organism individual = (Organism)organismList.get(i);
      
      if(!individual.isDead()){ // Check if dead. If not continue with rendering.
      
           individual.updateAlphaMultiplier(organismList.size()); // The rate at which each organism dies becomes faster as the number of
                                                                  // organisms in the environment goes higher.
       
           if(!individual.isAboutToDie())// If it is about to die, trigger decayFunction, if not continue with growth
              individual.growthFunction(growthThreshold); 
            else
              individual.decayFunction();
              
       
          individual.updateLocation();
          individual.drawOrganism();
      }else {
        organismList.remove(i); /// If the organism is dead, remove it from the organism List, so that memory is not wasted
      }
      }//for loop

  }
}//function end

public void mouseReleased()
{
  if(startFlag > 1){ // To make sure mouse clicks will instantiate the organism ONLY after the front and instruction page have been already passed
  if(!((mouseX > 560 && mouseX < 610) && 
      ((mouseY > 40 && mouseY < 70) || (mouseY > 110 && mouseY < 140) || (mouseY > 20 && mouseY < 60)))){
   //To check whether the click was in the growth rate/up/down boxes or not  
      organismList.add(new Organism()); 

   }else{
  
    if(mouseY > 40 && mouseY < 70)
       updateGrowthParam(1);   // If "UP" button was pressed
    else if(mouseY > 110 && mouseY < 140)
       updateGrowthParam(-1); // If "DOWN" button was pressed.
       
   }
  } 
}

public void keyPressed(){ //Keeping track of space bar hits to increment the flag.
   
    if(key == ' ')
      startFlag += 1 ;
  
}

public void updateGrowthParam(int direction){
  
    if(direction ==  1){ //If direction was up, reduce the actual randomization threshold, so that the rate is higher
      
      growthThreshold = growthThreshold - 0.005f;
      if(growthThreshold <= 0.89f)
        growthThreshold = 0.89f;
      
      growthValueDisplay = growthValueDisplay + 1;
      
      
    }else if (direction == -1){ //If direction was down, increase the actual randomization threshold, so that the rate is lower
      growthThreshold = growthThreshold + 0.005f;
      if(growthThreshold >= 0.99f)
        growthThreshold = 0.99f;
      
      growthValueDisplay = growthValueDisplay - 1;
     
    }

    if(growthValueDisplay >= 20) // Bound the display value between 1 and 20
         growthValueDisplay = 20;
     if(growthValueDisplay <= 1)
        growthValueDisplay = 1;
}

public void mouseDragged() 
{
  PVector currentMousePoint = new PVector(mouseX, mouseY,0);
  PVector oldMousePoint = new PVector(pmouseX, pmouseY,0);  
  
  PVector accelVector = PVector.sub(currentMousePoint, oldMousePoint); //To determine the direction of motion of the organisms
  accelVector.normalize(); //Just needs the direction
  
  for(int i=0; i < organismList.size(); i++)
  {
    Organism individual = (Organism)organismList.get(i);
    individual.applyForce(accelVector);
  }

}
// Class describing each node of the organism with respect to the organism's center.

class Node{

  PVector centerLoc; //This is wrt the organism center.
  float radius;    //Final radius of the sphere
  float radInc;   // variable to keep track of increasing radius
  boolean isFirst; //Bool to keep track of the first sphere in the organism. This sphere does not grow with time...but is drawn at the full radius
                   //right in the beginning itself
  float perlinInc; //Perlin noise param.

  
  Node(PVector center, float rad, boolean setIsFirst){
    
  this.centerLoc = center.get();
  radius = rad;
  radInc = 0;
  isFirst = setIsFirst;
  perlinInc = 0;
 
  }
  
  public void drawNode(){
    
    pushMatrix();
    shininess(map(noise(perlinInc), 0, 1, 10, 50)); // random shininess for the sphere.
    
    radInc += 0.3f;
    if(radInc >= radius)
      radInc = radius;
      
    translate(centerLoc.x,centerLoc.y,centerLoc.z); 
    
    if(!isFirst)
      sphere(radInc);
    else
      sphere(radius); // The central node doesnt grow...it is drawn at the full radius right from the beginning. 
      
    popMatrix();
  
    perlinInc += 0.7f;
  }
  
  public void moveOutwards(){ // The organism breaks apart and the nodes will fly away from each other.
    centerLoc.mult(1.053f);
  }
  
}

class Organism{
  
 
  PVector organismCenterLoc3D; // Origin of the organism with respect to top left corner of the window
  PVector translationVelocity; //The component of translational velocity that will be affected gusts of wind.
  PVector jiggleVelocity;      //The component of translational velocity that will be affected by jiggles

 
  float blendFactor; float green, blue;
  
  //*******Lists for nodes and parents***********
  
  ArrayList nodeList;
  ArrayList parentList;
  
  
  float OrganismLifeMultiplier; // This variable will be dynamically updated before the growth(), decay() and also from the main sketch as other organism die and take birth. 
  float lifeTime;
  
  float theta, translateStepSize;
  
  int colorAliveOrganism;
  int colorDyingOrganism;
  
  
  
  ///******Constructor*********
  
  Organism(){
     
      //The multiplier variable should be assigned depending on how many other organism are already out there...So when an organism take birth, if there are already lot of organisms in the pool it wont have resources to live long thereofre the lifetime variable will be small
  //The constructor is only called at the BEGINNING of the life cycle of an organism. That is the constructor will be called when the mouse is clicked. 
  //The constructor will add the first node (sphere) to the node list. The first node will be centered at the origin of the coordinate system associated with the organism (this coordinate
  //system will have its origin at mouseX, mouseY and big -ve z.
    
    nodeList = new ArrayList();
    parentList = new ArrayList();
    colorAliveOrganism = color(255); //Pure white for the time being
    colorDyingOrganism = color(255, 255, 255);  //To facilitate blending from white to red
    
    organismCenterLoc3D = new PVector(mouseX, mouseY, 0); //Center of the organism with respect to world coordinates;
    translationVelocity = new PVector(0,0,0);
    
    PVector firstNodeCenter = new PVector(0,0,0); //First node is at the origin of the coordinate system assocaited with the organism. 
    nodeList.add(new Node(firstNodeCenter, 10 + random(40), true)); //initialize and allocate the first element of the node list and add it to the node list array.
    parentList.add(-1); // make the first element of parentList to be -1 indicating no parent for node number 1.
    
    
    OrganismLifeMultiplier = 1;
    theta = 0;
    translateStepSize = random(2000); //The param for PerlinNoiseStep size.
    lifeTime = 200 + random(150);
    blendFactor = 0.97f;
    green = 255;
    blue = 255;
    
  }
  
  //*********Member functions*****************
  
  
  ///************Update Functions - Movement and Lifetime*****************
  public void updateAlphaMultiplier(float multiplier){
    
    OrganismLifeMultiplier = multiplier;
  }
  
   public void updateLifetime(){
    
   lifeTime -= 0.4f*OrganismLifeMultiplier;
    if(lifeTime<= 0)
      lifeTime= 0;
  }
  
  public void updateRotational(){
    
    rotateX(map(noise(theta), 0, 1, 0, TWO_PI));
    rotateY(map(noise(theta + 1000), 0, 1, 0, TWO_PI));
    rotateZ(map(noise(theta + 2000), 0, 1, 0, TWO_PI));
    theta += 0.005f;
  }
  
    public void jiggle(){
    
    translateStepSize += 0.05f;
    float randomTemp = random(1);// (A number between 0 and 1)  
    float stepSizeX = map(noise(translateStepSize), 0, 1, -4, 4);  // Brownian motion kind of behaviour using perlin noise
    float stepSizeY = map(noise(translateStepSize+3000), 0, 1, -4, 4);
    
    jiggleVelocity = new PVector(stepSizeX, stepSizeY, -random(-2, 6)); //The z coordinate is constantly reduced during the jiggle so 
                                                                    //that the organism recedes further and farther away from the user
  }       
  
  public void updateLocation(){
    
    jiggle(); //This is always happening. So include it in the beginning of updateLocation
    effectOfPush();
     
    organismCenterLoc3D.add(translationVelocity);  // Gust of wind  triggered by mouse dragging.
    organismCenterLoc3D.add(jiggleVelocity);   //always happening   

    checkEdges(); 
   
  }
  
  ///******************************Force and edge detection************************
  
  public void effectOfPush(){
       translationVelocity.mult(1.1f);
  }
  
//  void fluidResistance(){
//    
////   if(translationVelocity.mag() >= 60){
////     translationVelocity.mult(0.89);   
//     if(translationVelocity.mag() < 20)
//       translationVelocity.mult(0);
//   
//  }
  
  public void checkEdges(){
    
   if(organismCenterLoc3D.x < 0)
       organismCenterLoc3D.x = 0;
  
    if(organismCenterLoc3D.x > width)
      organismCenterLoc3D.x = width;
    
    if(organismCenterLoc3D.y < 0)
      organismCenterLoc3D.y = 0;
    
    if(organismCenterLoc3D.y > height)
      organismCenterLoc3D.y = height;
  }
  
  public void applyForce(PVector force){
     translationVelocity = new PVector(force.x, force.y, 0);
 
  }
  


///*************Growth and Decay Functions***********************

  public void growthFunction(float growthThreshold){
  // This is the method where new nodes will be added randomly(or this is the place to implement growth algorithms
  // This will add new nodes to the node list. when a new node is being created a random node from the existing list is taken and made a parent node to this new born node. 
  //As the organism grows the z becomes more and more positive
  //Do not add a node EVERYTIME the growth is called...The organism will be a super monster...
  
  float growthRand = random(1);
  
  if(abs(growthRand) > growthThreshold){ // Two levels of threshold so that the organism dont end up becoming a MONSTER!! 
      float secondGrowthRand = random(1);
      if(abs(secondGrowthRand) > 0.2f){
        
        int randParent = (int)random(5000) % nodeList.size(); // Choose a random parent from the existing node list for the next new born node. 
        parentList.add(randParent); //Add the new parent index to the parentList
        
        Node parentNode = (Node)nodeList.get(randParent); 
        
        float parentRadius = parentNode.radius;
        PVector parentCenterLoc = parentNode.centerLoc.get();
        
        float distOfNewNodeFromParentCenter = parentRadius + random(500)%(parentRadius - 20) + 20; // Created a random combined radii for parent and child
        float newNodeRadius = distOfNewNodeFromParentCenter - parentRadius;  // Extract the value for child radius, needed while we instantiate a new node
        float combinedRadius = parentRadius + newNodeRadius;
        
        float randTheta = random(TWO_PI);  // Spherical coordinates - random theta and phi. to determine the direction of growth.
        float randPhi = random(TWO_PI) - PI; //azimuthal angle
        
        PVector vectorBetweenSpheres = new PVector(combinedRadius*sin(randTheta)*cos(randPhi),
                                                   combinedRadius*cos(randTheta)*cos(randPhi),
                                                   combinedRadius*sin(randPhi));
        
        PVector newNodeCenterLoc = PVector.add(parentCenterLoc,vectorBetweenSpheres); //Calculate new sphere center vector. This is with respect to the center of the organism
        nodeList.add(new Node((newNodeCenterLoc), newNodeRadius, false));    // Add a new sphere to the node list.
        
      
       // colorAliveOrganism = color(255, 255,255);
        fill(colorAliveOrganism, 255);   
     
      } //secondGrowthRand If Statement
    } //growthRand IFstatement
    
  }  //End of FunctionBRace;

  public void decayFunction(){
    
    green = green*blendFactor; // slowly blend from white to red. decrease green and blue equally by a constant factor everytime the decay Function is called..
    blue = blue*blendFactor;
    
    
    colorDyingOrganism = color(255, green, blue);
    fill(colorDyingOrganism, 255);
    
    for(int i=0; i<nodeList.size(); i++){ // To have the individual nodes fly apart, by moving the spheres along the lines connecting the center of the organism and the node center
      Node node = (Node)nodeList.get(i);
      node.moveOutwards();
    }  
  }
  
  public void drawOrganism(){
    
    pushMatrix();
    updateLifetime();
   
    translate(organismCenterLoc3D.x,organismCenterLoc3D.y, organismCenterLoc3D.z); // translate to organism center
    updateRotational(); //Topple the organism a little bit
    
    for(int i=0; i<nodeList.size(); i++){
      Node node = (Node)nodeList.get(i);
      node.drawNode(); // Render each node with respect to the organism center.
    }  
   
    popMatrix();
 
    fill(colorAliveOrganism, 255); // This is needed here or else after one organism dies, everything else after that will be ready.. 
                                   //  We have to reset the alive color everytime this func is called.
  }  
  
  
  ///*********Checking state functions****************
  
  
   public boolean isDead(){
     
    if(lifeTime<= 40) // If the lifeTime drops below 50 declare the organism to be dead so that it can be removed from the main list
      return true;
    else
     return false;
  }
  
  public boolean isAboutToDie(){ // Indicator for when to trigger the decay sequence
    
    if(lifeTime<= 120)
      return true;
    else
      return false;
  }
  
} // End of Class
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--full-screen", "--bgcolor=#666666", "--stop-color=#cccccc", "MolecularSoup" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
